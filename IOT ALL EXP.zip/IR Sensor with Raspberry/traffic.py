# Circuit Connections:
# Here’s how to connect the 3 LEDs (Red, Yellow, Green) to the Raspberry Pi:

# Red LED:

# Anode (long leg) → GPIO 17 (Pin 11 on Raspberry Pi)
# Cathode (short leg) → GND (through a 220Ω resistor) pin 4
# Yellow LED:

# Anode (long leg) → GPIO 27 (Pin 13 on Raspberry Pi)
# Cathode (short leg) → GND (through a 220Ω resistor) pin 14
# Green LED:

# Anode (long leg) → GPIO 22 (Pin 15 on Raspberry Pi) pin 20
# Cathode (short leg) → GND (through a 220Ω resistor)

import RPi.GPIO as GPIO
import time

# Set up GPIO mode
GPIO.setmode(GPIO.BCM)

# Define GPIO pins for the LEDs
RED_LED = 17
YELLOW_LED = 27
GREEN_LED = 22

# Set up the GPIO pins
GPIO.setup(RED_LED, GPIO.OUT)
GPIO.setup(YELLOW_LED, GPIO.OUT)
GPIO.setup(GREEN_LED, GPIO.OUT)

# Function to turn off all LEDs
def turn_off_all():
    GPIO.output(RED_LED, GPIO.LOW)
    GPIO.output(YELLOW_LED, GPIO.LOW)
    GPIO.output(GREEN_LED, GPIO.LOW)

# Traffic light sequence
def traffic_light_sequence():
    # Red light on
    GPIO.output(RED_LED, GPIO.HIGH)
    print("Red Light ON")
    time.sleep(5)  # Red light for 5 seconds

    # Yellow light on
    GPIO.output(RED_LED, GPIO.LOW)
    GPIO.output(YELLOW_LED, GPIO.HIGH)
    print("Yellow Light ON")
    time.sleep(2)  # Yellow light for 2 seconds

    # Green light on
    GPIO.output(YELLOW_LED, GPIO.LOW)
    GPIO.output(GREEN_LED, GPIO.HIGH)
    print("Green Light ON")
    time.sleep(5)  # Green light for 5 seconds

    # Turn off all lights before the next cycle
    turn_off_all()

# Main loop
try:
    while True:
        traffic_light_sequence()  # Run traffic light sequence

except KeyboardInterrupt:
    print("Program stopped by user")

finally:
    GPIO.cleanup()  # Clean up GPIO settings on exit
