# Circuit Connection:
# 1. IR Sensor Module (e.g., HC-SR501) to Raspberry Pi:
# VCC (IR Sensor) → 5V (Raspberry Pi)
# GND (IR Sensor) → GND (Raspberry Pi)
# OUT (IR Sensor) → GPIO 17 (Pin 11 on Raspberry Pi) (You can choose other GPIO pins as well)
# 2. LED to Raspberry Pi:
# Anode (long leg of LED) → GPIO 18 (Pin 12 on Raspberry Pi)
# Cathode (short leg of LED) → GND (through a 220Ω resistor)
# 14,20 no pin is also GND

import RPi.GPIO as GPIO
import time

# Set up GPIO mode and pins
GPIO.setmode(GPIO.BCM)

# Define pin numbers
IR_SENSOR_PIN = 17      # GPIO pin connected to IR sensor OUT
LED_PIN = 18            # GPIO pin connected to LED
BUZZER_PIN = 23         # GPIO pin connected to Buzzer (optional)

# Set up the GPIO pins
GPIO.setup(IR_SENSOR_PIN, GPIO.IN)  # IR Sensor as input
GPIO.setup(LED_PIN, GPIO.OUT)       # LED as output
GPIO.setup(BUZZER_PIN, GPIO.OUT)    # Buzzer as output (optional)

# Function to notify the user (e.g., by turning on a buzzer and LED)
def notify_user():
    print("Object detected!")
    GPIO.output(LED_PIN, GPIO.HIGH)  # Turn on the LED
    GPIO.output(BUZZER_PIN, GPIO.HIGH)  # Turn on the Buzzer
    time.sleep(1)  # Keep the notification for 1 second
    GPIO.output(LED_PIN, GPIO.LOW)  # Turn off the LED
    GPIO.output(BUZZER_PIN, GPIO.LOW)  # Turn off the Buzzer

try:
    while True:
        # Read the IR sensor's output
        if GPIO.input(IR_SENSOR_PIN):
            print("No object detected.")
        else:
            notify_user()  # Call the function when an object is detected
        time.sleep(0.1)  # Small delay to prevent CPU overuse

except KeyboardInterrupt:
    print("Program interrupted")

finally:
    GPIO.cleanup()  # Clean up GPIO settings on exit
